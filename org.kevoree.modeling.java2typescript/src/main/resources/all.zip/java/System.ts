class System {

    static out = {
        println(obj:any) {
            console.log(obj);
        },
        print(obj:any) {
            console.log(obj);
        }
    }

    static err = {
        println(obj:any) {
            console.log(obj);
        },
        print(obj:any) {
            console.log(obj);
        }
    }

}