class Throwable {
    printStackTrace(){
        throw new Exception("Abstract implementation");
    }
}
