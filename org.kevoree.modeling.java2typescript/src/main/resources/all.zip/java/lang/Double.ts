class Double {
    public static parseDouble(val:string):number {
        return Number(val);
    }
}