class Short {
    public static parseShort(val : string) : number {
        return Number(val);
    }
}