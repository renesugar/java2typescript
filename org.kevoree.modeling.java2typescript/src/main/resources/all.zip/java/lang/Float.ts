class Float {
    public static parseFloat(val : string) : number {
        return Number(val);
    }
}