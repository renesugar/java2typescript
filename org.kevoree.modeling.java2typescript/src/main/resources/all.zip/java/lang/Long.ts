class Long {
    public static parseLong(val : string) : number {
        return Number(val);
    }
}