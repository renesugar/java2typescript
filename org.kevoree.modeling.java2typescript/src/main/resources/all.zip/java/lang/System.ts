class System {

    static arraycopy(data:Number[], number:Number, d:Number[], number2:Number, numElements:Number):void {
        
    }
}