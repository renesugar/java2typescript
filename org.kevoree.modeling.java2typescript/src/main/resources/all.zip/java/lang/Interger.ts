class Integer {
    public static parseInt(val:string):number {
        return Number(val);
    }
}