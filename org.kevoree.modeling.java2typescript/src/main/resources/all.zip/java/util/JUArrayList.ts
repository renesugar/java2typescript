///<reference path="JUList.ts"/>
class JUArrayList<T> extends JUList<T> {

}