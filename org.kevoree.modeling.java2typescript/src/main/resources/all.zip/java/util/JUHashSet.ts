///<reference path="JUSet.ts"/>
class JUHashSet<T> extends JUSet<T> {

}