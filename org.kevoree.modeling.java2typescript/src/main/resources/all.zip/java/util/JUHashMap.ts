///<reference path="JUMap.ts"/>
class JUHashMap<K, V> extends JUMap<K,V> {

}